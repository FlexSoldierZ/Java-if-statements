let x = 5.4
let y = 6

if(y > x )

console.log("Je hebt een voldoende")
console.log("Einde programma")
