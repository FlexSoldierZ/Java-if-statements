let y = 5.4
let x = 7

if(x > y)
console.log("je hebt een voldoende")
else
console.log("je hebt een onvoldoende")



console.log("einde programma")

