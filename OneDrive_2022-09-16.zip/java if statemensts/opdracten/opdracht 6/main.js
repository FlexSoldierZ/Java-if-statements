prompt("Vul wachtwoord in")

let wachtwoord = "Hond";
let ww = 5

if(wachtwoord === ww)
console.log("u bent ingelogd")
else
console.log("U wachtwoord is incorret, probeer het opnieuw")


