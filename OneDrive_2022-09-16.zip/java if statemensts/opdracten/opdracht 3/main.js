let x = 5
let y = 5

if(5 == 5)
console.log("Je moet herkansen!")

console.log("Einde programma")