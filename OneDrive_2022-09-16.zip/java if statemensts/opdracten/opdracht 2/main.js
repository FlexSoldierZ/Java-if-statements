let x = 5.5
let cijfer = 4.7


if(cijfer < x)
console.log ("je hebt een onvoldoende")


console.log("einde programma")