

//let a = "docent"
//= "directeur"
let a  = prompt("Vul de gebruiker in");


if(a == "docent") {
    alert("Jij bent een docent");
} else if (a == "directeur") {
    alert("jij bent directeur");
} else if(a == "student") {
    alert("jij bent student");
}
else alert("Jij bent gek!");




let b = prompt("Vul je wachtwoord in");

if(b == "bob1212"){
    alert("Wachtwoord correct");
} 
else alert("Wachtwoord incorrect");


let c = prompt("vul je leeftijd in");

if(c == "18"){
    alert("leeftijd correct");
} 
else alert("minder jarig");