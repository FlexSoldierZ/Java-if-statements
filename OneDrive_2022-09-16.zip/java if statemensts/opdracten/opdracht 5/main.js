prompt("Vul je wachtwoord in")

let wachtwoord = "hond"

if("hond")
console.log("u bent ingelogd")